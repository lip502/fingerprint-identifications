function varargout = fingerprint_identification(varargin)
% FINGERPRINT_IDENTIFICATION MATLAB code for fingerprint_identification.fig
%      FINGERPRINT_IDENTIFICATION, by itself, creates a new FINGERPRINT_IDENTIFICATION or raises the existing
%      singleton*.
%
%      H = FINGERPRINT_IDENTIFICATION returns the handle to a new FINGERPRINT_IDENTIFICATION or the handle to
%      the existing singleton*.
%
%      FINGERPRINT_IDENTIFICATION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FINGERPRINT_IDENTIFICATION.M with the given input arguments.
%
%      FINGERPRINT_IDENTIFICATION('Property','Value',...) creates a new FINGERPRINT_IDENTIFICATION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before fingerprint_identification_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to fingerprint_identification_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES


gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @fingerprint_identification_OpeningFcn, ...
    'gui_OutputFcn',  @fingerprint_identification_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before fingerprint_identification is made visible.
function fingerprint_identification_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to fingerprint_identification (see VARARGIN)

% Choose default command line output for fingerprint_identification
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes fingerprint_identification wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = fingerprint_identification_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in inputfingerprint.
function inputfingerprint_Callback(hObject, eventdata, handles)
% hObject    handle to inputfingerprint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename,pathname]=uigetfile({'*.bmp';'*.tif';'*.*'},'����ͼ��');
if isequal(filename,0)|isequal(pathname,0)
    errordlg('û��ѡ���ļ�','����');
    return;
else
    file=[pathname,filename];
    global S   %����һ��ȫ�ֱ���S�������ʼͼ��·�����Ա�֮��Ļ�ԭ����
    S=file;
    x=imread(file);
    set(handles.axes1,'HandleVisibility','ON');
    axes(handles.axes1);
    imshow(x);
    
    I111=x;
    I=x;
    [m n]=size(I);
    M=0;var=0;
    I=double(I);
    for x=1:m
        for y=1:n
            M=M+I(x,y);
        end
    end
    M1=M/(m*n);
    for x=1:m
        for y=1:n
            var=var+(I(x,y)-M1).^2;
        end
    end
    var1=var/(m*n);
    for x=1:m
        for y=1:n
            if I(x,y)>=M1
                I(x,y)=150+sqrt(2000*(I(x,y)-M1)/var1);
            else
                I(x,y)=150-sqrt(2000*(M1-I(x,y))/var1);
            end
        end
    end
    axes(handles.axes5);
    imshow(I,[]);
    %% �ָ�
    M =3;      %3*3
    H = m/M;
    L= floor(n/M);
    aveg1=zeros(H,L);
    var1=zeros(H,L);
    % ����ÿһ���ƽ��ֵ
    for x=1:H;
        for y=1:L;
            aveg=0;var=0;
            for i=1:M;
                for j=1:M;
                    aveg=I(i+(x-1)*M,j+(y-1)*M)+aveg;
                end
            end
            aveg1(x,y)=aveg/(M*M);
            % ����ÿһ��ķ���ֵ
            for i=1:M;
                for j=1:M;
                    var=(I(i+(x-1)*M,j+(y-1)*M)-aveg1(x,y)).^2+var;
                end
            end
            var1(x,y)=var/(M*M);
        end
    end
    Gmean=0;Vmean=0;
    for x=1:H
        for y=1:L
            Gmean=Gmean+aveg1(x,y);
            Vmean=Vmean+var1(x,y);
        end
    end
    Gmean1=Gmean/(H*L);%���п��ƽ��ֵ
    Vmean1=Vmean/(H*L);%���п�ķ���
    gtemp=0;gtotle=0;vtotle=0;vtemp=0;
    for x=1:H
        for y=1:L
            if Gmean1>aveg1(x,y)
                gtemp=gtemp+1;
                gtotle=gtotle+aveg1(x,y);
            end
            if Vmean1<var1(x,y)
                vtemp=vtemp+1;
                vtotle=vtotle+var1(x,y);
            end
        end
    end
    G1=gtotle/gtemp;V1=vtotle/vtemp;
    gtemp1=0;gtotle1=0;vtotle1=0;vtemp1=0;
    for x=1:H
        for y=1:L
            if G1<aveg1(x,y)
                gtemp1=gtemp1-1;
                gtotle1=gtotle1+aveg1(x,y);
            end
            if 0<var1(x,y)<V1
                vtemp1=vtemp1+1;
                vtotle1=vtotle1+var1(x,y);
            end
        end
    end
    G2=gtotle1/gtemp1;V2=vtotle1/vtemp1;
    
    e=zeros(H,L);
    for x=1:H
        for y=1:L
            if aveg1(x,y)>G2 && var1(x,y)<V2
                e(x,y)=1;
            end
            if aveg1(x,y)< G1-100 && var1(x,y)< V2
                e(x,y)=1;
            end
        end
    end
    for x=2:H-1
        for y=2:L-1
            if e(x,y)==1
                if e(x-1,y) + e(x-1,y+1) +e(x,y+1) + e(x+1,y+1) + e(x+1,y) + e(x+1,y-1) + e(x,y-1) + e(x-1,y-1) <=4
                    e(x,y)=0;
                end
            end
        end
    end
    Icc = ones(m,n);
    for x=1:H
        for y=1:L
            if  e(x,y)==1
                for i=1:M
                    for j=1:M
                        I(i+(x-1)*M,j+(y-1)*M)=G1;
                        Icc(i+(x-1)*M,j+(y-1)*M)=0;
                    end
                end
            end
        end
    end
    axes(handles.axes6);
    imshow(I,[]);
    %% ��ֵ��
    temp=(1/9)*[1 1 1;1 1 1;1 1 1];%ģ��ϵ��     ��ֵ�˲�
    Im=double(I);
    In=zeros(m,n);
    for a=2:m-1;
        for b=2:n-1;
            In(a,b)=Im(a-1,b-1)*temp(1,1)+Im(a-1,b)*temp(1,2)+Im(a-1,b+1)*temp(1,3)+Im(a,b-1)*temp(2,1)+Im(a,b)*temp(2,2)+Im(a,b+1)*temp(2,3)+Im(a+1,b-1)*temp(3,1)+Im(a+1,b)*temp(3,2)+Im(a+1,b+1)*temp(3,3);
        end
    end
    I=In;
    Im=zeros(m,n);
    for x=5:m-5;
        for y=5:n-5;
            sum1=I(x,y-4)+I(x,y-2)+I(x,y+2)+I(x,y+4);
            sum2=I(x-2,y+4)+I(x-1,y+2)+I(x+1,y-2)+I(x+2,y-4);
            sum3=I(x-2,y+2)+I(x-4,y+4)+I(x+2,y-2)+I(x+4,y-4);
            sum4=I(x-2,y+1)+I(x-4,y+2)+I(x+2,y-1)+I(x+4,y-2);
            sum5=I(x-2,y)+I(x-4,y)+I(x+2,y)+I(x+4,y);
            sum6=I(x-4,y-2)+I(x-2,y-1)+I(x+2,y+1)+I(x+4,y+2);
            sum7=I(x-4,y-4)+I(x-2,y-2)+I(x+2,y+2)+I(x+4,y+4);
            sum8=I(x-2,y-4)+I(x-1,y-2)+I(x+1,y+2)+I(x+2,y+4);
            sumi=[sum1,sum2,sum3,sum4,sum5,sum6,sum7,sum8];
            summax=max(sumi);
            summin=min(sumi);
            summ=sum(sumi);
            b=summ/8;
            if (summax+summin+ 4*I(x,y))> (3*summ/8)
                sumf = summin;
            else
                sumf =summax;
            end
            if   sumf > b
                Im(x,y)=128;
            else
                Im(x,y)=255;
            end
        end
    end
    for i=1:m
        for j =1:n
            Icc(i,j)=Icc(i,j)*Im(i,j);
        end
    end
    for i=1:m
        for j =1:n
            if (Icc(i,j)==128)
                Icc(i,j)=0;
            else
                Icc(i,j)=1;
            end;
        end
    end
    axes(handles.axes7);
    imshow(Icc,[]);
    %% ȥ�ն���ë��
    u=Icc;
    [m,n]=size(u); %ȥ���ն���ë��
    for x=2:m-1
        for y=2:n-1
            if u(x,y)==0
                if u(x,y-1)+u(x-1,y)+u(x,y+1)+u(x+1,y)>=3
                    u(x,y)=1;
                end
            else u(x,y)=u(x,y);
            end
        end
    end
    for a=2:m-1
        for b=2:n-1
            if u(a,b)==1
                if abs(u(a,b+1)-u(a-1,b+1))+abs(u(a-1,b+1)-u(a-1,b))+abs(u(a-1,b)-u(a-1,b-1))+abs(u(a-1,b-1)-u(a,b-1))+abs(u(a,b-1)-u(a+1,b-1))+abs(u(a+1,b-1)-u(a+1,b))+abs(u(a+1,b)-u(a+1,b+1))+abs(u(a+1,b+1)-u(a,b+1))~=1%Ѱ�Ҷ˵�
                    if(u(a,b+1)+u(a-1,b+1)+u(a-1,b))*(u(a,b-1)+u(a+1,b-1)+u(a+1,b))+(u(a-1,b)+u(a-1,b-1)+u(a,b-1))*(u(a+1,b)+u(a+1,b+1)+u(a,b+1))==0 %ȥ���ն���ë��
                        u(a,b)=0;
                    end
                end
            end
        end
    end
    
    %% ϸ��
    v=~u;
    se=strel('square',3);
    fo=imopen(v,se);
    v=imclose(fo,se); %��ͼ����п������ͱղ���
    w=bwmorph(v,'thin',Inf);%��ͼ�����ϸ��
    
    axes(handles.axes2);
    %figure;
    txy=point(w);
    [w,txy]=guanghua(w,txy);
    thin=w;
    txy=cut(thin,txy);
    [pxy,error2]=last1(thin,5,txy,40);
    error=1;
    num=20;
    load('fingerprint.mat');
    fingerprint1=cell(1,1);
    fingerprint1{1}.pxy=pxy;
    fingerprint1{1}.txy=txy;
    fingerprint1{1}.thin=thin;
    fingerprint1{1}.image=x;
    fingerprint=[fingerprint;I111];
    save('fingerprint.mat','fingerprint');
    %    handles.img=x;
    guidata(hObject,handles);
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename,pathname]=uigetfile({'*.bmp';'*.bmp';'*.tif';'*.*'},'����ͼ��');
if isequal(filename,0)|isequal(pathname,0)
    errordlg('û��ѡ���ļ�','����');
    return;
else
    file=[pathname,filename];
    global S   %����һ��ȫ�ֱ���S�������ʼͼ��·�����Ա�֮��Ļ�ԭ����
    S=file;
    x=imread(file);
    set(handles.axes3,'HandleVisibility','ON');
    axes(handles.axes3);
    imshow(x);
    handles.img=x;
    guidata(hObject,handles);
end
% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
msgbox('�����ƣ�Qѧ��115195686')


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fingerprint=cell(0,1);
str1=sprintf('˵��\n\n');
str2=sprintf(' ָ��ʶ��ϵͳ[һ�Զ�]����Q�ң�115195686 \n');
string=[str1 str2];
msgbox(string,'��ܰ��ʾ','none');
save('fingerprint.mat','fingerprint');



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
